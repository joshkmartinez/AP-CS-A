public abstract class Shape
{
}