public class Box extends Rectangle
{
    // variables
    private double height;
    
    // constructor
    public Box( double length, double width, double height )
    {
        super( length, width );
        this.height = height;
    }
    
    // methods
    
    public String toString()
    {
        return "This box holds this volume: " + volume();
    }
    
    public double getHeight()
    {
        return height;
    }
    
    public void setHeight( double newHeight )
    {
        height = newHeight;
    }
    
    public double volume()
    {
        return super.area() * height;
    }
}