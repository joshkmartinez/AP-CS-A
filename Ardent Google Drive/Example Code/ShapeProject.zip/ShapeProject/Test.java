public class Test
{
    public static void main( String[] args )
    {
        Shape[] data = new Shape[ 5 ];
        
        Circle c1 = new Circle( 2.5 );
        Disc d1 = new Disc( 2.4, 3.1 );
        Rectangle r1 = new Rectangle( 4.5, 6.0 );
        Box b1 = new Box( 2.0, 3.0, 5.0 );
        
        data[ 0 ] = c1;
        data[ 1 ] = d1;
        data[ 2 ] = r1;
        data[ 3 ] = b1;
        
        for( Shape s : data )
        {
            System.out.print( s + "\n" );
        }
    }
}