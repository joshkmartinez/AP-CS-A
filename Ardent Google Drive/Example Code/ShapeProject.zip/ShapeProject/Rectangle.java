public class Rectangle extends Shape
{
    // variables
    private double length;
    private double width;
    
    // constructor
    public Rectangle( double length, double width )
    {
        this.length = length;
        this.width = width;
    }
    
    // methods
    public String toString()
    {
        return "This is a rectangle of length " + length + " and width " + width + ".";
    }
    
    public double getLength()
    {
        return length;
    }
    
    public void setLength( double newLength )
    {
        length = newLength;
    }
    
    public double getWidth()
    {
        return width;
    }
    
    public void setWidth( double newWidth )
    {
        width = newWidth;
    }
    
    public double area()
    {
        return length * width;
    }
    
    public double perimeter()
    {
        return length * 2 + width * 2;
    }
}