public class Circle extends Shape
{
    // variables
    public static final double PI = 3.14159;
    private double radius;
    
    // constructor
    public Circle()
    {
        this.radius = 1.0;
    }
    
    public Circle( double radius )
    {
        this.radius = radius;
    }
    
    // methods
    public String toString()
    {
        return "This is a circle of radius: " + radius;
    }
    
    public double getRadius()
    {
        return radius;
    }
    
    public void setRadius( double newRadius )
    {
        radius = newRadius;
    }
    
    public double area()
    {
        return PI * radius * radius;
    }
}