public class Disc extends Circle
{
    // variables
    private double height;
    
    // constructor
    public Disc( double radius, double height )
    {
        super( radius );
        this.height = height;
    }
    
    // methods
    
    public String toString()
    {
        return "This is disc of radius " + super.getRadius() + " and height " + height + ".";
    }
    
    public double getHeight()
    {
        return height;
    }
    
    public void setHeight( double newHeight )
    {
        height = newHeight;
    }
    
    public double volume()
    {
        return super.area() * height;
    }
}