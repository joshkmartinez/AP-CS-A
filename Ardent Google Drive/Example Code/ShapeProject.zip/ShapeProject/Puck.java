public class Puck extends Disc
{
    // variables
    public static final double radius = 1.5;
    public static final double height = 1.0;
    private double weight;
    
    // constructor
    public Puck( double weight )
    {
        super( radius, height );
        this.weight = weight;
    }
    
    // methods
    public String toString()
    {
        return "This hockey puck weighs: " + weight;
    }
    
    public double getWeight()
    {
        return weight;
    }
    
    public void setWeight( double newWeight )
    {
        weight = newWeight;
    }
        
}