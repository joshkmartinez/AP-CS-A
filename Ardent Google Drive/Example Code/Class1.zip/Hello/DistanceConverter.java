import java.util.Scanner;

public class DistanceConverter
{
    public static void main( String[] args )
    {
        Scanner input = new Scanner( System.in );
        
        // prompt the user for a distance in miles - INPUT
        System.out.print( "Enter a distance in miles: ");
        double miles = input.nextDouble();
        
        // convert the distance from miles to kilometers - COMPUTATION
        double kilometers = miles * 1.6;
        
        // print out the results - OUTPUT
        System.out.println( "The equivalent distance in kilometers is: " + kilometers );
    }
}