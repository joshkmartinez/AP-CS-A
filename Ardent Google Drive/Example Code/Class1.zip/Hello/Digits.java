import java.util.Scanner;

public class Digits
{
    public static void main( String[] args )
    {
        Scanner input = new Scanner( System.in );
        
        // prompt the user for a two-digit number
        System.out.print( "Please enter a two-digit number: " );
        int num = input.nextInt();
        
        // get the tens place
        int tens = num / 10;
        
        // get the ones place
        int ones = num % 10;
        
        // display the results
        System.out.println("Tens place: " + tens );
        System.out.println("Ones place: " + ones );
    }
}