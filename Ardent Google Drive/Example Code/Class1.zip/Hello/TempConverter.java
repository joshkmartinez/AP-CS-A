import java.util.Scanner;

public class TempConverter
{
    public static void main( String[] args )
    {
        Scanner input = new Scanner( System.in );
        
        // prompt the user for a temperature in Fahrenheit- INPUT
        System.out.print( "Enter a temperature in Fahrenheit: ");
        double fTemp = input.nextDouble();
        
        // convert from F to C - COMPUTATION
        double cTemp = ( fTemp - 32 ) * 5.0 / 9.0;
        
        // print out the results - OUTPUT
        System.out.println( "The equivalent temperature in Celsius is: " + cTemp );
    }
}