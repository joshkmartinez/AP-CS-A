import java.util.Scanner;

public class Parsecs
{
    public static void main( String[] args )
    {
        Scanner input = new Scanner( System.in );
        
        // prompt the user for a distance in Parsecs - INPUT
        System.out.print( "Enter a distance in Parsecs: ");
        double parsecs = input.nextDouble();
        
        // convert from parsecs to ly - COMPUTATION
        double lightYears = parsecs * 3.26;
        
        // print out the results - OUTPUT
        System.out.println( "The equivalent distance in light-years is: " + lightYears );
    }
}