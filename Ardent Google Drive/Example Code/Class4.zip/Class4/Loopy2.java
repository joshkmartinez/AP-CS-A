public class Loopy2
{
    public static void main( String[] args )
    {
        int counter = 1;
        while( counter <= 100 )
        {
            if( counter % 7 == 0 ) System.out.print( counter + " " );
            counter++;
        }
        
        System.out.println();
        
        for( int i = 1; i <= 100; i++ )
        {
            if( i % 7 == 0 ) System.out.print( i + " " );
        }
        
        System.out.println();
        
        for( int i = 98; i > 0; i -= 7 )
        {
            System.out.print( i + " " );
        }
        
        System.out.println();
        
        counter = 14;
        while( counter > 0 )
        {
            int printValue = counter * 7;
            System.out.print( printValue + " " );
            counter --;
        }
    }
}