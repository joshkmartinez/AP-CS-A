import java.util.Scanner;

public class Quad
{
    public static void main( String[] args )
    {
        // declare and instantiate a Scanner object called input
        Scanner input = new Scanner( System.in );
        
        // INPUT: get the values a, b, and c from the user
        System.out.print( "Enter a value for a: " );
        double a = input.nextDouble();
        
        System.out.print( "Enter a value for b: " );
        double b = input.nextDouble();
        
        System.out.print( "Enter a value for c: " );
        double c = input.nextDouble();
        
        // COMPUTATION: solve the quadratic formula
        //x1 = ( -b + Math.sqrt( (b * b) - (4 * a * c ) ) ) / ( 2 * a )
        //x2 = ( -b - Math.sqrt( (b * b) - (4 * a * c ) ) ) / ( 2 * a )
        double x1 = ( -b + Math.sqrt( (b * b) - (4 * a * c ) ) ) / ( 2 * a );
        double x2 = ( -b - Math.sqrt( (b * b) - (4 * a * c ) ) ) / ( 2 * a );
        
        // OUTPUT: display the results
        System.out.println( x1 + " and " + x2 );
    }
}