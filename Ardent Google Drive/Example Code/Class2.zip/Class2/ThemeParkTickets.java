import java.util.Scanner;

public class ThemeParkTickets
{
    public static void main( String[] args )
    {
        Scanner input = new Scanner( System.in );
        
        System.out.println( "Theme Park Tickets!" );
        
        System.out.print( "Enter your age: ");
        int age = input.nextInt();
        
        if( age <= 3 ) System.out.println( "Free admission." );
        else if( age < 10 ) System.out.println( "$200 admission." );
        else if( age < 65 ) System.out.println( "$500 admission." );
        else if( age < 100 ) System.out.println( "$250 admission." );
        else System.out.println( "Free super senior admission." );
    }
}