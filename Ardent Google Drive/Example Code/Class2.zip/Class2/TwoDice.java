import java.util.Random;

public class TwoDice
{
    public static void main( String[] args )
    {
        Random gen = new Random();
        int max = 6;
        int min = 1;
        
        // roll number cube 1
        System.out.println( "Rolling number cube 1..." );
        int nc1 = gen.nextInt((max-min) + 1 ) + min;
        
        // roll number cube 2
        System.out.println( "Rolling number cube 2..." );
        int nc2 = gen.nextInt((max-min) + 1 ) + min;
        
        // add up their values and display the total
        System.out.println( "Number cube 1 value: " + nc1 );
        System.out.println( "Number cube 2 value: " + nc2 );
        
        int total = nc1 + nc2;
        
        System.out.println( "Total of both rolls: " + total );
        
    }
}