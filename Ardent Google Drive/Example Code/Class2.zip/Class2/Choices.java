public class Choices
{
    public static void main( String[] args )
    {
        int a = 5;
        int b = 6;
        
        if( a < 5 )
        {
            System.out.println( "Hello!" );
        }
        else
        {
            System.out.println( "Goodbye." );
        }
        
        if( b + 3 > 8 )
        {
            System.out.println( "Woah!" );
        }
    }
}