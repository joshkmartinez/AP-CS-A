import java.util.Scanner;

public class Methods1
{
    // new print functions to save time
    public static void print( String s )
    {
        System.out.print( s );
    }
    
    public static void println( String s )
    {
        System.out.println( s );
    }
    
    // write a method that converts miles to kilometers
    public static double distanceConvert( double miles )
    {
        double kilometers = miles * 1.6;
        return kilometers;
    }
    
    // write a method that converts parsecs to light years
    public static double galacticDistance( double parsecs )
    {
        double lightYears = parsecs * 3.26;
        return lightYears;
    }
    
    // write a method that calculates the total of a purchase plus sales tax
    // the method should accept the amount of the purchase plus the percentage of tax to be applied
    public static double calcPrice( double cost, double taxPercentage )
    {
        double tax = ( taxPercentage / 100.0 );
        double taxAmount = cost * tax;
        double total = cost + taxAmount;
        return total;
    }
    
    // write a method that accepts an array of integers and a multiplier value
    // multiply each integer in the array by the multiplier value
    // return a new array with the new values
    public static int[] multArray( int[] nums, int mult )
    {
        int[] results = new int[ nums.length ];
        
        for( int i = 0; i < nums.length; i++ )
        {
            results[ i ] = nums[ i ] * mult;
        }
        
        return results;
    }
    
    // CLIENT CODE
    public static void main( String[] args )
    {
        Scanner input = new Scanner( System.in );
        
        // convert miles to kilometers
        System.out.print( "Enter a distance in miles: " );
        double mi = input.nextDouble();
        double km = distanceConvert( mi );
        System.out.println( "The equivalent distance in kilometers is: " + km );
        
        // convert parsecs to light years
        print( "Enter a distance in parsecs: " );
        double p = input.nextDouble();
        double ly = galacticDistance( p );
        println( "The equivalent distance in light years is: " + ly );
        
        // calculate the total cost of a purchase
        print( "Enter the price of your purchase: " );
        double price = input.nextDouble();
        print( "Enter the sales tax rate: " );
        double taxRate = input.nextDouble();
        double totalCost = calcPrice( price, taxRate );
        println( "The total cost is: " + totalCost );
        
        // test the array mult method
        int[] nums = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
        println( "Original array: " );
        for( int i = 0; i < nums.length; i++ )
        {
            print( nums[ i ] + " " );
        }
        println("");
        print( "Enter an integer multiplier: " );
        int m = input.nextInt();
        int[] newNums = multArray( nums, m );
        println( "New array: " );
        for( int i = 0; i < newNums.length; i++ )
        {
            print( newNums[ i ] + " " );
        }
        
    }
}
