public class PerfectSquare
{
    // new print functions to save time
    public static void print( String s )
    {
        System.out.print( s );
    }
    
    public static void println( String s )
    {
        System.out.println( s );
    }
    
    // check for perfect square
    public static boolean isPerfectSquare( int number )
    {
        double root = Math.sqrt( number );
        int truncRoot = (int) root;
        int square = truncRoot * truncRoot;
        
        if( square == number ) return true;
        else return false;
    }
    
    public static void main( String[] args )
    {
        int[] nums = { 4, 5, 8, 9, 14, 16, 25 };
        int psCount = 0;
        
        for( int i = 0; i < nums.length; i++ )
        {
            if( isPerfectSquare( nums[ i ] ) )
            {
                psCount++;
            }
        }
        
        int mid = (int) nums.length / 2;
        if( psCount > mid ) println( "Yes." );
        else println( "No." );
    }
}