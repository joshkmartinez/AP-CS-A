/**
 * Calendar Project - Framework
 * October 2018 - Mr. Wie
 */

import java.util.Scanner;

public class Calendar
{
    /**
     * Print Function - print with no newline
     */
    public static void print( String s )
    {
        System.out.print( s );
    }
    
    /**
     * Print Function - print with newline
     */
    public static void println( String s )
    {
        System.out.println( s );
    }
    
    /**
     * Top Level Stub
     */
    private static void printMonth( int year, int month )
    {
        printMonthTitle( year, month );
        printMonthBody( year, month );
    }
    
    /**
     * Second Level Stub - printMonthTitle
     * (includes dummy values)
     */
    private static void printMonthTitle( int year, int month )
    {
        // this is a dummy value for testing purposes only
        println( "June 2006" );
    }
    
    /**
     * Second Level Stub - printMonthBody
     * (includes dummy values)
     */
    private static void printMonthBody( int year, int month )
    {
        // hint: this is where you call the methods that you write
        println( "the numbers go here" );
    }
    
    /**
     * Base Level Methods
     * All the methods we described go here--all currently have dummy values you must replace!
     */
    
    private static void printDay( int day )
    {
        print( "   " );
    }
    
    private static int getStartDay( int year, int month )
    {
        return 1;
    }
    
    private static int getTotalNumberOfDays( int year, int month )
    {
        return 100;
    }
    
    private static int getDaysInMonth( int year, int month )
    {
        return 28;
    }
    
    private static boolean isLeapYear( int year )
    {
        return false;
    }
    

    /**
     * CLIENT CODE
     */
    public static void main( String[] args )
    {
        Scanner input = new Scanner( System.in );
        
        print( "Enter a complete year: " );
        int year = input.nextInt();
        
        print( "Enter a month: " );
        int month = input.nextInt();
        
        // print out the calendar
        printMonth( year, month );

    }
}