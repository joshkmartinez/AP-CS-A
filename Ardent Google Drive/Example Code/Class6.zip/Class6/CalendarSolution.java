/**
 * Calendar Project - Solution
 * October 2018 - Mr. Wie
 */

import java.util.Scanner;

public class CalendarSolution
{
    /**
     * Print Function - print with no newline
     */
    public static void print( String s )
    {
        System.out.print( s );
    }
    
    /**
     * Print Function - print with newline
     */
    public static void println( String s )
    {
        System.out.println( s );
    }
    
    /**
     * Top Level Stub
     */
    public static void printMonth( int year, int month )
    {
        printMonthTitle( year, month );
        printMonthBody( year, month );
    }
    
    /**
     * Second Level Stub - printMonthTitle
     * (includes dummy values)
     */
    public static void printMonthTitle( int year, int month )
    {
        String sMonth = "";
        
        // switch time!
        switch( month )
        {
            case 1:  sMonth = "        January"; break;
            case 2:  sMonth = "       February"; break;
            case 3:  sMonth = "         March"; break;
            case 4:  sMonth = "         April"; break;
            case 5:  sMonth = "          May"; break;
            case 6:  sMonth = "         June"; break;
            case 7:  sMonth = "         July"; break;
            case 8:  sMonth = "        August"; break;
            case 9:  sMonth = "       September"; break;
            case 10: sMonth = "        October"; break;
            case 11: sMonth = "       November"; break;
            case 12: sMonth = "       December"; break;
        }
        
        // first line of calendar
        println( sMonth + " " + year );
        
        // dashes and day names
        println( "---------------------------" );
        println( "Sun Mon Tue Wed Thu Fri Sat" );
    }
    
    /**
     * Second Level Stub - printMonthBody
     * (includes dummy values)
     */
    public static void printMonthBody( int year, int month )
    {
        // figure out what day of the week we're starting on
        int currentDayOfWeek = getStartDay( year, month );
        
        // print out the extra spaces in front of it under each of the days
        for( int i = 1; i <= currentDayOfWeek; i++ )
        {
            print( "    " );
        }
        
        // print the days sequentially
        
        // step 1: get the total days
        int totalDays = getDaysInMonth( year, month );
        
        // step 2: print each row
        for( int day = 1; day <= totalDays; day++ )
        {
            printDay( day );
            currentDayOfWeek++;
            
            if( currentDayOfWeek == 7 )
            {
                currentDayOfWeek = 0;
                println( "" );
            }
            else if( day == totalDays )
            {
                println( "" );
            }
        }
    }
    
    
    
    /**
     * Base Level Methods
     * All the methods we described go here--all currently have dummy values you must replace!
     */
    
    // print one day, and handle the extra space for 1 digit days
    public static void printDay( int day )
    {
        // one digit
        if( day < 10 )
        {
            print( "  " + day + " " );
        }
        else
        {
            print( " " + day + " " );
        }
    }
    
    // tell us which day of the week to start printing the calendar
    public static int getStartDay( int year, int month )
    {
        int day = ( getTotalNumberOfDays( year, month ) + 6 ) % 7;
        
        // handle day being negative
        day = ( day + 7 ) % 7;
        
        return day;
    }
    
    // return the total number of days since Saturday, January 1, 2000, my epoch date.
    public static int getTotalNumberOfDays( int year, int month )
    {
        // what variables must I track?
        int days = 0;
        int currentMonth = 1;
        int currentYear = 2000;
        
        // use the helper method getDaysInMonth() to get values to add
        if( year >= 2000 )
        {
            while( currentYear < year || currentMonth < month )
            {
                days += getDaysInMonth( currentYear, currentMonth );
                
                // go to the next month
                if( currentMonth < 12 )
                {
                    currentMonth++;
                }
                else
                {
                    currentYear++;
                    currentMonth = 1;  // january
                }
            }
        }
        else if( year < 2000 )
        {
            while( currentYear > year || currentMonth > month )
            {
                days -= getDaysInMonth( currentYear, currentMonth );
                
                if( currentMonth > 1 )
                {
                    currentMonth--;
                }
                else
                {
                    currentYear--;
                    currentMonth = 12;   // december
                }
            }
        }
        
        return days;
    }
    
    // tell us how many days are in the month for a specified year
    public static int getDaysInMonth( int year, int month )
    {
        // array with a significant index
        int[] daysInMonth = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
        int days = daysInMonth[ month ];
        
        // leap year handler
        if( month == 2 )
        {
            if( isLeapYear( year ) )
            {
                days++;
            }
        }
        
        return days;
    }
    
    // Leap Year function
    public static boolean isLeapYear( int year )
    {
        if( year % 400 == 0 ) return true;
        if( year % 100 == 0 ) return false;
        if( year % 4 == 0 ) return true;
        return false;
    }
    

    /**
     * CLIENT CODE
     */
    public static void main( String[] args )
    {
        Scanner input = new Scanner( System.in );
        
        print( "Enter a complete year: " );
        int year = input.nextInt();
        
        print( "Enter a month: " );
        int month = input.nextInt();
        
        // print out the calendar
        printMonth( year, month );

    }
}