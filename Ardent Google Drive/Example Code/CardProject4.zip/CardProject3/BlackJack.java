public class BlackJack
{
    public static void main( String[] args )
    {
        // arrays of ranks, suites, and values
        String[] ranks = { "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A" };
        String[] suits = { "Clubs", "Diamonds", "Hearts", "Spades" };
        int[] values = { 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10, 11 };  // blackjack values
        
        // create a new deck
        Deck d = new Deck( ranks, suits, values );
        
        // shuffle the deck
        d.shuffle();
        
        // create two hands and deal the first two cards to them
        Card p1 = d.deal();
        Card d1 = d.deal();
        Card p2 = d.deal();
        Card d2 = d.deal();
        
        Hand player = new Hand( p1, p2 );
        Hand dealer = new Hand( d1, d2 );
        
        // print out both hands for testing purposes
        // check first to make sure your data flows correctly between objects
        System.out.println( "Player's hand:\n" + player );
        System.out.println( "Value of player hand: " + player.getHandValue() + "\n" );
        
        System.out.println( "Dealer's hand:\n" + dealer );
        System.out.println( "Value of dealer hand: " + dealer.getHandValue() );
    }
}