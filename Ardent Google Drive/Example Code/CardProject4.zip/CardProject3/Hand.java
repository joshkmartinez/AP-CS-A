import java.util.ArrayList;

public class Hand
{
    // variables
    private ArrayList<Card> cards;
    private int handValue;
    private boolean isBust;
    
    // constructor
    public Hand( Card card1, Card card2 )
    {
        cards = new ArrayList<Card>();
        
        cards.add( card1 );
        cards.add( card2 );
        
        // calculate the handValue
        handValue = card1.getValue() + card2.getValue();
        
        // set isBust
        isBust = false;
    }
    
    // methods
    
    // function to get the handValue
    public int getHandValue()
    {
        // do I handle the ace problem here?
        return handValue;
    }
    
    // function to add a card to the hand
    // loop in here to solve the ace problem--what about multiple aces?
    // should I handle the ace problem here?
    public void add( Card newCard )
    {
    }
    
    // toString() method for the hand
    public String toString()
    {
        String handString = "";
        // go through the arraylist of cards and add them to the deckstring
        for( Card c : cards )
        {
            handString += c + "\n";
        }
        return handString;
    }
    
}   