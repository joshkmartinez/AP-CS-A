import java.util.ArrayList;

public class PiggyBank
{
    private ArrayList<Coin> bank;
    
    public PiggyBank()
    {
        bank = new ArrayList<Coin>();
    }
    
    // methods
    
    // toString method
    public String toString()
    {
        String bankString = "";
        for( Coin c : bank )
        {
            bankString += c + "\n";
        }
        return bankString;
    }
    
    // put a coin into the bank
    public void addCoin( Coin c )
    {
        bank.add( c );
    }
    
    // count the total number of coins in the bank
    public int numCoins()
    {
        int num = bank.size();
        return num;
    }
    
    // count the total faceValue of all the coins in the bank
    public double totalValue()
    {
        // accumulator variable for the total value of all the coins in the bank
        double value = 0.0;
        
        for( Coin c : bank )
        {
            // get the faceValue from every coin and add it to vale
            value += c.getFaceValue();
        }
        
        return value;
    }
}