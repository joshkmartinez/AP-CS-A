public class TestPiggyBank
{
    public static void main( String[] args )
    {
        PiggyBank myMoney = new PiggyBank();
        
        Coin q = new Coin( "Quarter", 0.25, 2018 );
        Coin d = new Coin( "Dime", 0.10, 2018 );
        Coin n = new Coin( "Nickel", 0.05, 2018 );
        Coin p = new Coin( "Penny", 0.01, 2018 );
        
        myMoney.addCoin( q );
        myMoney.addCoin( d );
        myMoney.addCoin( n );
        myMoney.addCoin( p );
        myMoney.addCoin( q );
        myMoney.addCoin( q );
        myMoney.addCoin( n );
        myMoney.addCoin( p );
        myMoney.addCoin( p );
        myMoney.addCoin( q );
        
        System.out.println( "Number of coins in the bank: " + myMoney.numCoins() );
        
        System.out.println( "The total value of coins in the bank is: " + myMoney.totalValue() );
        
        System.out.println( myMoney );
    }
}