public class Coin
{
    // variables - STATE
    private String name;
    private double faceValue;
    private int year;

    // constructor
    public Coin( String n, double fv, int y )
    {
        name = n;
        faceValue = fv;
        year = y;
    }
    
    // methods - BEHAVIOR
    
    public String toString()
    {
        String coinString = name + ", " + faceValue + ", " + year + ".";
        return coinString;
    }
    
    public String getName()
    {
        return name;
    }
    
    public double getFaceValue()
    {
        return faceValue;
    }
    
    public int getYear()
    {
        return year;
    }
    
}