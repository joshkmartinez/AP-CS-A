public class Cell
{
    // variables
    private boolean alive;
    
    // constructor
    public Cell( boolean a )
    {
        alive = a;
    }
    
    // methods
    public boolean alive()
    {
        return alive;
    }
}