public class TestRobot
{
    public static void main( String[] args )
    {
        Robot robby = new Robot( "Robby", 10, "Red" );
        
        System.out.println( "The name of the robot is: " + robby.getName() );
        System.out.println( "The age of the robot is: " + robby.getAge() );
        System.out.println( "The favorite color of the robot is: " + robby.getFavoriteColor() );
        
        robby.setName( "Roberta" );
        robby.setFavoriteColor( "Pink" );
        
        System.out.println( "The name of the robot is: " + robby.getName() );
        System.out.println( "The age of the robot is: " + robby.getAge() );
        System.out.println( "The favorite color of the robot is: " + robby.getFavoriteColor() );
        
        robby.randomGreeting();
        robby.setMood();
        
        System.out.println( "The robot's current mood is: " + robby.getMood() );
        robby.rayGun();
        
    }
}