/**
 *  Robot Class - November 2018
 */

import java.util.Random;

public class Robot
{
    // variables
    private String name;
    private int age;
    private String favoriteColor;
    private String mood;
    private Random gen;
    
    /**
     * Constructor
     * 
     * @param   String n
     * @param   int a
     * @param   String fc
     */
    public Robot( String n, int a, String fc )
    {
        name = n;
        age = a;
        favoriteColor = fc;
        mood = "Happy";
        gen = new Random();
    }
    
    /**
     * Get the robot's name.
     */
    public String getName()
    {
        return name;
    }
    
    /**
     * Set the robot's name.
     * 
     * @param   String newName
     */
    public void setName( String newName )
    {
        name = newName;
    }
    
    /**
     * Get the robot's age.
     */
    public int getAge()
    {
        return age;
    }
    
    /**
     * Get the robot's favorite color.
     */
    public String getFavoriteColor()
    {
        return favoriteColor;
    }
    
    /** 
     * Set the robot's favorite color
     * 
     * @param   String newColor
     */
    public void setFavoriteColor( String newColor )
    {
        favoriteColor = newColor;
    }
    
    /**
     * Generate a random greeting.
     */
    public void randomGreeting()
    {
        int randomNum = gen.nextInt( 4 );
        if( randomNum == 0 ) System.out.println( "Hello!" );
        else if( randomNum == 1 ) System.out.println( "Goodbye!" );
        else if( randomNum == 2 ) System.out.println( "What?" );
        else System.out.println( "You're ugly!" );
    }
    
    /**
     * Set the robot's mood (randomly generated).
     */
    public void setMood()
    {
        int rn = gen.nextInt( 6 );
        switch( rn )
        {
            case 0: mood = "Happy"; break;
            case 1: mood = "Sad"; break;
            case 2: mood = "Angry"; break;
            case 3: mood = "Depressed"; break;
            case 4: mood = "Psychotic"; break;
            case 5: mood = "Apathetic"; break;
        }
    }
    
    /**
     * Get the robot's mood.
     */
    public String getMood()
    {
        return mood;
    }
    
        /**
     * Fire the robot's raygun if it is in the right mood.
     */
    public void rayGun()
    {
        if( mood.equals( "Angry" ) || mood.equals( "Psychotic" ) )
        {
            System.out.println( "Prepare to die, hyoo-man!" );
            System.out.println( "PEW PEW PEW" );
        }
        else
        {
            System.out.println( "I'm not really feeling this whole death ray thing right now, sorry." );
        }
    }
        
}