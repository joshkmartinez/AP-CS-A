public class TestFakeDeck
{
    public static void main( String[] args )
    {
        // arrays of ranks, suites, and values
        String[] ranks = { "1", "2", "3", "4", "5" };
        String[] suits = { "Frog", "Horse", "Lion", "Unicorn", "Dragon" };
        int[] values = { 1, 2, 3, 4, 5 };
        
        // create a new deck
        Deck d = new Deck( ranks, suits, values );
        
        // print out the deck
        System.out.println( d );
    }
}