import java.util.Scanner;

public class Recursion
{
    public static int factorial( int n )
    {
        // base case
        if( n == 1 ) return 1;

        // recursive call
        // System.out.println( "Recursive call at n = " + n );
        return n * factorial( n - 1 );
    }   
    
    public static int fib( int n )
    {
        // base case
        if( n <= 2 ) return 1;
    
        // recursive call
        return fib( n - 1 ) + fib( n - 2 );
    }

    
    public static void main( String[] args )
    {
        Scanner input = new Scanner( System.in );
        System.out.print( "Enter a number n for factorial calculation: " );
        int n = input.nextInt();
        
        for( int i = 1; i <= n; i++ )
        {
            System.out.println( "Factorial of " + i + " is: " + factorial( i ) );
        }
        
        System.out.print( "Enter a number n for Fibonacci calculation: " );
        int fibNum = input.nextInt();
        
        for( int i = 1; i <= fibNum; i++ )
        {
            System.out.println( "Fib of " + i + " is: " + fib( i ) );
        }
    }
}
