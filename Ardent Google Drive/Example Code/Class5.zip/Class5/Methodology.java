import java.util.Scanner;

public class Methodology
{
    // print functions - to save time typing
    public static void print( String s )
    {
        System.out.print( s );
    }
    
    public static void println( String s )
    {
        System.out.println( s );
    }
    
    // write a method that converts Fahrenheit to Celsius
    public static double tempConvert( double fTemp )
    {
        double cTemp = ( fTemp - 32 ) * ( 5.0 / 9.0 );
        return cTemp;
    }
    
    // write a method that converts Celsius to Kelvin
    public static double tempConvert2( double cTemp )
    {
        double kTemp = cTemp + 273.15;
        return kTemp;
    }
    
    // main function =  CLIENT CODE
    public static void main( String[] args )
    {
        Scanner input = new Scanner( System.in );
        
        // prompt the user for a Fahrenheit temperature
        print( "Enter a Fahrenheit temperature: " );
        double fTemp = input.nextDouble();
        
        // display the equivalent temperatures in Celsius and Kelvin by calling the methods above
        double cTemp = tempConvert( fTemp );
        double kTemp = tempConvert2( cTemp );
        
        println( "Celsius: " + cTemp );
        println( "Kelvin: " + kTemp );
    }
}