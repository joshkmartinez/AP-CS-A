public class MethodPractice
{
    // print functions - to save time typing
    public static void print( String s )
    {
        System.out.print( s );
    }
    
    public static void println( String s )
    {
        System.out.println( s );
    }
    
    // write a method that performs currency exchange between GBP and USD
    // visit www.xe.com for the current market exchange rate
    public static double moneyConvert( double gbp )
    {
        double usd = gbp * 1.31142;
        return usd;
    }
    
    // write a method that accepts a year, and determines whether that year is a leap year or not
    // the test, IN ORDER:
    // 1. a year is a leap year if it is divisible by 400
    // 2. a year is not a leap year if it is divisible by 100
    // 3. a year is a leap year if it is divisible by 4
    // 4. otherwise, it is not a leap year
    public static boolean isLeapYear( int year )
    {
        if( year % 400 == 0 ) return true;
        else if( year % 100 == 0 ) return false;
        else if( year % 4 == 0 ) return true;
        else return false;
    }
    
    // write a method that solves the quadratic formula
    
    
    
    // CLIENT CODE
    public static void main( String[] args )
    {
    }
}