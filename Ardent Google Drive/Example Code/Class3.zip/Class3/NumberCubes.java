import java.util.Random;

public class NumberCubes
{
    public static void main( String[] args )
    {
        Random gen = new Random();
        int min = 1;
        int max = 6;
        
        // roll two six-sided number cubes
        int nc1 = gen.nextInt( (max-min) + 1 ) + min;
        int nc2 = gen.nextInt( (max-min) + 1 ) + min;
        
        // display each number cube
        System.out.println( "Number cube 1 result: " + nc1 );
        System.out.println( "Number cube 2 result: " + nc2 );
        
        // display the total
        int total = nc1 + nc2;
        System.out.println( "Total of both cubes: " + total );
        
    }
}