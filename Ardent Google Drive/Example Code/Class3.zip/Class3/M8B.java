import java.util.Scanner;
import java.util.Random;

public class M8B
{
    public static void main( String[] args )
    {
        Scanner input = new Scanner( System.in );
        Random gen = new Random();
        
        System.out.println( "Magic 8 Ball!" );
        
        // prompt the user for a yes/no question
        System.out.print( "Enter a yes/no question: " );
        String question = input.next();
        
        // generate a random response
        int min = 1;
        int max = 4;
        int response = gen.nextInt( (max-min) + 1 ) + min;
        
        // choose the random response
        if( response == 1 )
            System.out.println( "Yes!" );
        else if( response == 2 )
            System.out.println( "No!" );
        else if( response == 3 )
            System.out.println( "Maybe." );
        else
            System.out.println( "You're ugly!" );
    }
}