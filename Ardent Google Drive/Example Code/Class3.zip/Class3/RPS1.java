import java.util.Scanner;
import java.util.Random;

public class RPS1
{
    public static void main( String[] args )
    {
        Scanner input = new Scanner( System.in );
        Random gen = new Random();
        
        System.out.println( "Rock, Paper, Scissors!" );
        
        // prompt the user for their throw
        System.out.print( "Enter 1-Rock, 2-Paper, 3-Scissors: " );
        int player = input.nextInt();
        
        // error handling of user input
        if( player < 1 || player > 3 )
        {
            System.out.println( "Invalid input detected. Selecting rock by default." );
            player = 1;
        }
        
        // display the user's throw
        if( player == 1 ) System.out.println( "Player throws Rock." );
        else if( player == 2 ) System.out.println( "Player throws Paper." );
        else System.out.println( "Player throws Scissors." );
        
        // randomly generate the computer's throw
        int max = 3;
        int min = 1;
        int comp = gen.nextInt( (max-min) + 1 ) + min;
        
        // display the computer's throw
        if( comp == 1 ) System.out.println( "Computer throws Rock." );
        else if( comp == 2 ) System.out.println( "Computer throws Paper." );
        else System.out.println( "Computer throws Scissors." );
        
        // compare the results and declare a winner
        if( player == comp )
            System.out.println( "The game is a tie." );
        else if( player==1 && comp==3 || player==2 && comp==1 || player==3 && comp==2 )
            System.out.println( "The player wins the game!" );
        else System.out.println( "The computer wins the game!" );
    }
}
        