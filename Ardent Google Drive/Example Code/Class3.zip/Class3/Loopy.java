public class Loopy
{
    public static void main( String[] args )
    {
        // print 1-20
        for( int i = 1; i <= 20; i++ )
        {
            System.out.print( i + " " );
        }
        
        System.out.println();
        
        // print 10 to 1 descending
        for( int i = 10; i > 0; i-- )
        {
            // note: + sign for strings is concatenation
            System.out.print( i + " " );
        }
        
        System.out.println();
        
        // print 1-20 with a while loop
        int counter = 1;
        while( counter <= 20 )
        {
            System.out.print( counter + " " );
            counter++;
        }
        
        System.out.println();
        
        // print 10 to descending with a while loop
        counter = 10;
        while( counter > 0 )
        {
            System.out.print( counter + " " );
            counter--;
        }
    }
}