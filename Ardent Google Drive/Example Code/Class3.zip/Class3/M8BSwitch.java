import java.util.Scanner;
import java.util.Random;

public class M8BSwitch
{
    public static void main( String[] args )
    {
        Scanner input = new Scanner( System.in );
        Random gen = new Random();
        
        System.out.println( "Magic 8 Ball!" );
        
        // prompt the user for a yes/no question
        System.out.print( "Enter a yes/no question: " );
        String question = input.next();
        
        // generate a random response
        int min = 1;
        int max = 6;
        int response = gen.nextInt( (max-min) + 1 ) + min;
        
        // choose the random response
        switch( response )
        {
            case 1: System.out.println( "Yes!" );
                    break;
            case 2: System.out.println( "No." );
                    break;
            case 3: System.out.println( "Maybe." );
                    break;
            case 4: System.out.println( "You're ugly!" );
                    break;
            default: System.out.println( "Error...try again." );
        }
    }
}