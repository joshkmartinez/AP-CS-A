public class Rectangle
{
    // variables
    private double length;
    private double width;
    
    // constructor
    public Rectangle( double l, double w )
    {
        length = l;
        width = w;
    }
    
    // methods
    
    public double getLength()
    {
        return length;
    }
    
    public void setLength( double newLength )
    {
        length = newLength;
    }
    
    public double getWidth()
    {
        return width;
    }
    
    public void setWidth( double newWidth )
    {
        width = newWidth;
    }
    
    public double area()
    {
        return length * width;
    }
    
    public double perimeter()
    {
        return 2 * length + 2 * width;
    }
}