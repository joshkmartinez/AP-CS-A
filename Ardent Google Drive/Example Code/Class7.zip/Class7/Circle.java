public class Circle
{
    // VARIABLE DECLARATIONS - STATE
    
    // class variable (static) that is a constant (final)
    // class variables are not copied into every object--referenced directly from the class
    public static final double PI = 3.14159;
    
    // instance variable
    private double radius;
    
    
    // CONSTRUCTOR
    
    // standard constructor without any variables - creates a unit circle
    public Circle()
    {
        radius = 1.0;
    }
    
    // overloaded constructor that accepts a radius
    public Circle( double newRadius )
    {
        radius = newRadius;
    }
    
    
    // METHODS - BEHAVIOR
    
    public double getRadius()
    {
        return radius;
    }
    
    public void setRadius( double newRadius )
    {
        radius = newRadius;
    }
    
    public double area()
    {
        return PI * radius * radius;
    }
    
    public double circ()
    {
        return 2 * PI * radius;
    }
}