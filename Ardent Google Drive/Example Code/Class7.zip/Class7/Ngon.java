public class Ngon
{
    // variables
    private int n;
    private int size;
    
    // constructor
    public Ngon( int sides, int length )
    {
        n = sides;
        size = length;
    }
    
    // methods
    public int getSides()
    {
        return n;
    }
    
    public void setSides( int numSides )
    {
        n = numSides;
    }
    
    public int getSize()
    {
        return size;
    }
    
    public void setSize( int newSize )
    {
        size = newSize;
    }
    
    public int sumInteriorAngles()
    {
        return ( n - 2 ) * 180;
    }
}