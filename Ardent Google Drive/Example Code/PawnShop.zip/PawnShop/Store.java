import java.util.ArrayList;

public class Store
{
    public static void main( String[] args )
    {
        ArrayList<Cost> inventory = new ArrayList<Cost>();
        
        inventory.add( new Bicycle() );
        inventory.add( new Watch() );
        inventory.add( new Hat() );
        inventory.add( new Guitar() );
        inventory.add( new DiningSet() );
    }
}