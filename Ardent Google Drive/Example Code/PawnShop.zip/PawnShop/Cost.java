public interface Cost
{
    int value();
}