public class TestDeck
{
    public static void main( String[] args )
    {
        // arrays of ranks, suites, and values
        String[] ranks = { "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A" };
        String[] suits = { "Clubs", "Diamonds", "Hearts", "Spades" };
        int[] values = { 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10, 11 };  // blackjack values
        
        // create a new deck
        Deck d = new Deck( ranks, suits, values );
        
        // print out the deck
        System.out.println( d );
        
        // deal a card
        Card c1 = d.deal();
        System.out.println( "Dealt card: " + c1 );
        
        // print out the deck again
        System.out.println( d );

    }
}