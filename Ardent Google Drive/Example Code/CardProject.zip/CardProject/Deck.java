import java.util.ArrayList;

public class Deck
{
    // variables
    private ArrayList<Card> cards;
    
    // constructor
    public Deck( String[] ranks, String[] suits, int[] values )
    {
        // don't forget to instantiate the arraylist!
        cards = new ArrayList<Card>();
        
        // populate the array
        for( int i = 0; i < suits.length; i++ )
        {
            for( int j = 0; j < ranks.length; j++ )
            {
                Card newCard = new Card( ranks[ j ], suits[ i ], values[ j ] );
                cards.add( newCard );
            }
        }
    }
    
    // methods
    public String toString()
    {
        String deckString = "";
        // go through the arraylist of cards and add them to the deckstring
        for( Card c : cards )
        {
            deckString += c + "\n";
        }
        return deckString;
    }
    
    public Card deal()
    {
        if( cards.size() > 0 )
        {
            Card dealtCard = cards.get( cards.size() - 1 );
            cards.remove( cards.size() - 1 );
            return dealtCard;
        }
        else return null;
    }
    
    public void perfectShuffle()
    {
        // your shuffle code goes here
    }
}